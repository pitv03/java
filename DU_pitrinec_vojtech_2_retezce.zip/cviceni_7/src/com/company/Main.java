/*
1] Nacitejte a pridavejte do StringBufferu po jednotlivych ASCII znacich (uzivatel muze zadat cokoliv) ale validni jsou pouze cisla,
plus znak a mezara a jeden zvoleny escape znak (kontrolujte po kazden inputu uzivatele)

2] po zadani specialniho znaku se ukonci nacitani cisel

3] Nactene cislo rozdelte na predponu samotne cislo skladajici se z deviti cisel (pozor na mezery)

4] Cislo zvalidujte a soucasne zjistete jestli je cislo symetricke podle prostredni (pate) cislice

5] Vypiste uziviteli zpravu a vystupni cislo naformatujte do +420 XXX XXX XXX

pouzivejte
    # regularni vyrazy
    # stringBuffer
    # funkce/tridy
 */

package com.company;

import java.io.IOException;

public class Main {

    public static boolean symetricke (StringBuffer retezec) {
        if((retezec.substring(4,5).equals(retezec.substring(12,13))) &&
                (retezec.substring(5,6).equals(retezec.substring(11,12))) &&
                        (retezec.substring(6,7).equals(retezec.substring(10,11))) &&
                                (retezec.substring(7,8).equals(retezec.substring(9,10))))
        {
            System.out.println("Cislo je symetricke.");
            return true;
        }
        System.out.println("Cislo neni symetricke.");
        return false;
    }

    public static void main(String[] args)throws IOException {
	// write your code here
        System.out.println("Zadejte retezec, ktery obsahuje telefonni cislo:");
        StringBuffer retezec = new StringBuffer();
        char c = (char) System.in.read();
        while (c!='\n'){
            if ((c == '0')||(c == '1')||(c == '2')||(c == '3')||(c == '4')||(c == '5')||(c == '6')||(c == '7')||(c == '8')||(c == '9')||(c == '+')){
             retezec.append(c);
            }
            c = (char) System.in.read();
        }

        if(retezec.length()!=13) {
            System.out.println("Nespravna delka vstupu.");
            return;
        }

        String vzorPredpony= "+420";
        if(!vzorPredpony.equals(retezec.substring(0,4))) {
            System.out.println("Nespravna predpona.");
            return;
        }

        symetricke(retezec);

        //System.out.println(retezec);

        String predpona = retezec.substring(0,4);
        String prvniCastCisla = retezec.substring(4,7);
        String druhaCastCisla = retezec.substring(7,10);
        String tretiCastCisla = retezec.substring(10,13);

        System.out.println(predpona + " " + prvniCastCisla + " " + druhaCastCisla + " " + tretiCastCisla);
    }
}
